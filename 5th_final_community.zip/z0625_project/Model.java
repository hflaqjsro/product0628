package javaexp.z0625_project;

public class Model {
	public void addAttribute(String key, Object ob) {
//		System.out.println("# 모델 데이터 처리");
//		System.out.println("key: "+key);
//		System.out.println("객체: "+ob);
	}
}
