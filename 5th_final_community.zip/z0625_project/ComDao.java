package javaexp.z0625_project;

import java.util.ArrayList;
import java.util.List;

public class ComDao {
	public ArrayList<Post> post(Post po){
		ArrayList<Post> postList = new ArrayList<Post>();
		postList.add(po);
		savePost(po);
		System.out.println(postList.toString());
		return postList;
	}
	ArrayList<Post> postListSave = new ArrayList<Post>();
	public ArrayList<Post> savePost(Post po) {
		postListSave.add(po);
		return postListSave;
	}
	
	public void loadPost() {
		System.out.println(postListSave);
	}
	
	

	
	ArrayList<Profile> profList = new ArrayList<Profile>();
	public ArrayList<Profile> profileSet(Profile prof) {
		profList.clear();
		profList.add(prof);
		System.out.println(profList.toString());
		return profList;
	}
	public ArrayList<Profile> profileView(){
		if(profList.isEmpty()) {
			profList.add(new Profile("기본 닉네임", "기본 사진"));
		}else {
			
		}
		System.out.println(profList.toString());
		return profList;
	}
	
}
