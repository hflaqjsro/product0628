package javaexp.a00_exp.teamP_05;

public class Member {
	String Num;

	public Member(String num) {
		super();
		Num = num;
	}

	public String getNum() {
		return Num;
	}

	public void setNum(String num) {
		Num = num;
	}
	
}
