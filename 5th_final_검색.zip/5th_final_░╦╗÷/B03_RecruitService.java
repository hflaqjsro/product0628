package javaexp.z00_TeamProject;

import java.util.ArrayList;
import java.util.Scanner;

import javaexp.z01_vo.Recruit;

public class B03_RecruitService {

	
	public void getsearchList() {
		C03_RecruitDao dao = new C03_RecruitDao();
		dao.getsearchList();
		System.out.println("# 서비스단 처리 [검색] #");
		System.out.println("[DAO로부터 전송 DB LIST]");
	}

	public void detailsearchList() {
		C03_RecruitDao dao = new C03_RecruitDao();
		dao.detailsearchList();
		System.out.println("# 서비스단 처리 [상세검색] #");
		System.out.println("[DAO로부터 전송 DB LIST]");
	}

	
}


