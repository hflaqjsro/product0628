CREATE TABLE PERSONAL (
  pName varchar2 (100),        -- 성명
  pIDNum number,               -- 고유번호

);  




CREATE TABLE COMPANYINFO (
  cName varchar2 (100) CONSTRAINT COMPANYINFO_cName_nn NOT NULL,        -- 기업명
  cNum varchar2 (8)  PRIMARY KEY,            -- 회원 고유번호(기업회원)
  occupation number CONSTRAINT COMPANYINFO_industry_nn NOT NULL,    -- 산업
  cIDNum number CONSTRAINT COMPANYINFO_cIDNum_nn NOT NULL, -- 사업자등록번호
  employees number,            -- 사원수
  classification varchar2 (50), -- 구분
  builDate date,               -- 설립일
  capital number,      --자본금
  totSales number,     -- 매출액 
  CEO varchar2 (30) CONSTRAINT COMPANYINFO_CEO_nn NOT NULL,           -- CEO 성명 
  salary number,          -- 초임
  mainRole varchar2 (100),       -- 주요사업
  insurance varchar2 (100),       -- 보험
  website varchar2 (150),        -- 홈페이지
  address varchar2 (200) CONSTRAINT COMPANYINFO_address_nn NOT NULL,        -- 주소
  credit varchar2 (20),          -- 신용등급
  details varchar2 (500)                --상세소개
);

SELECT * FROM COMPANYINFO;





SELECT RCTITLE 공고명, to_char(DEADLINE,'YYYY-MM-DD') 마감일, 
decode(progress, 1, '채용 진행중', 2, '공고 마감') "상태", 
ADDRESS1 근무지,ADDRESS2 상세주소, c.CSTR 경력, e.ESTR 최종합력, 
p.ETSTR 고용형태, o.OSTR 산업, j.JTSTR 직급, 
jp.JPSTR 직책, s.SSTR 연봉, DEPT 직무, PREFER 우대조건
FROM RECRUIT a, CAREER c, education e, 
EMPTYPE p, OCCUPATION o,
JOBTITLE j, JOBPOSITION jp, SALARY s
WHERE a.EDUCATION = e.ENUM 
AND a.CAREER = c.CNUM 
AND a.EMPTYPE = p.ETNUM 
AND a.OCCUPATION = o.ONUM
AND a.TITLE = j.JTNUM
AND a.POSITION = jp.JPNUM 
AND a.SALARY = s.SNUM
AND RCTITLE Like '%기숙사%' AND ADDRESS1 Like '%경기%' AND s.SSTR LIKE '3천~4천';




SELECT ci.cName 기업명, a.RCTITLE 공고명, to_char(DEADLINE,'YYYY-MM-DD') 마감일, 
c.CSTR 경력, e.ESTR 최종학력, p.ETSTR 고용형태, s.SSTR 연봉, a.ADDRESS1 근무지
FROM COMPANYINFO ci, RECRUIT a, CAREER c, education e, 
EMPTYPE p, SALARY s 
WHERE ci.CNUM = a.CNUM
AND a.EDUCATION = e.ENUM 
AND a.CAREER = c.CNUM 
AND a.EMPTYPE = p.ETNUM
AND a.SALARY = s.SNUM;


------ innerjoin 시도
SELECT ci.cName 기업명, a.RCTITLE 공고명, to_char(DEADLINE,'YYYY-MM-DD') 마감일, 
c.CSTR 경력, e.ESTR 최종학력, p.ETSTR 고용형태, s.SSTR 연봉, a.ADDRESS1 근무지
FROM RECRUIT a
	INNER JOIN COMPANYINFO ci ON a.CNUM = ci.CNUM 
	INNER JOIN CAREER c ON a.CAREER = c.CNUM 
	INNER JOIN EDUCATION e ON a.EDUCATION = e.ENUM  
	INNER JOIN EMPTYPE p ON a.EMPTYPE = p.ETNUM
	INNER JOIN SALARY s ON a.SALARY = s.SNUM
WHERE c.CSTR LIKE '%신입%' or ci.CNAME LIKE '%신입%' or a.RCTITLE LIKE'%신입%';  

SELECT ci.cName 기업명, a.RCTITLE 공고명, to_char(DEADLINE,'YYYY-MM-DD') 마감일, 
c.CSTR 경력, e.ESTR 최종학력, p.ETSTR 고용형태, s.SSTR 연봉, a.ADDRESS1 근무지
FROM RECRUIT a
	INNER JOIN COMPANYINFO ci ON a.CNUM = ci.CNUM 
	INNER JOIN CAREER c ON a.CAREER = c.CNUM 
	INNER JOIN EDUCATION e ON a.EDUCATION = e.ENUM  
	INNER JOIN EMPTYPE p ON a.EMPTYPE = p.ETNUM
	INNER JOIN SALARY s ON a.SALARY = s.SNUM;






CREATE TABLE RESUME (
  rsNum varchar(8) CONSTRAINT resume_rsNum_nn_pk PRIMARY key, -- 이력서 고유번호 (pk)
  pNum varchar(8) CONSTRAINT resume_pNum_nn NOT NULL REFERENCES personal(pnum), -- 회원 고유번호 ◀ (일반회원DB 조인에 사용)
  rsTitle varchar(300) CONSTRAINT resume_rsTitle_nn NOT null, -- 이력서 제목
  profileImage varchar2(3000), -- 사진 URL
  email varchar2(100) CONSTRAINT resume_email_nn NOT null, -- 이메일 주소
  mobile varchar2(15) CONSTRAINT resume_mobile_nn NOT null,-- 휴대폰 번호
  tel varchar2(15),  -- 전화번호 
  address1 varchar2(300) CONSTRAINT resume_address1_nn NOT null, -- 회원의 주소 (Daum 주소 api의 roadAddress 받아옴)
  address2 varchar2(600), -- 회원의 상세주소
  education NUMBER REFERENCES education(eNum), -- 최종학력 (ex. 1:'초등학교 졸업', 2:'중학교 졸업' ..)
  career NUMBER REFERENCES career(cnum), -- 경력 (ex. 1:'신입', 2:'1~3년'..)
  salary NUMBER REFERENCES salary (snum), -- 연봉 (ex. 1:'회사 내규에 따름', 2:'~2000만원'..)
  occupation NUMBER REFERENCES occupation(onum), -- 희망직종 (ex. 100:'서비스업', 200:'금융,은행업'..)
  --area number(10) -- 희망지역 (법정동코드 ex. 1100000000:서울특별시, 1111000000:서울특별시 종로구, 1111010100:서울특별시 종로구 청운동)
  isVisible_resume number(1) -- 이력서 공개 여부 1:TRUE, 0:FALSE 
);  
			
DROP TABLE resume;
SELECT * FROM resume;
SELECT a.rsTitle 이력서제목, a.profileImage 프로필사진, p.pname 이름,
		TRUNC(MONTHS_BETWEEN(SYSDATE, p.birth)/12) 나이,
		a.email 이메일, a.mobile 휴대전화, a.address1 주소1, a.address2 주소2,
		b.estr 최종학력, c.cStr 경력, d.sStr 희망연봉, e.ostr 희망직종
FROM resume a 
	INNER JOIN education b ON a.education=b.enum 
	INNER JOIN CAREER c ON  a.career=c.cnum
	INNER JOIN salary d ON a.salary=d.snum
	INNER JOIN occupation e ON  a.occupation=e.onum
	inner JOIN personal p ON a.pNum=p.pNum 
WHERE a.rsNum='rs000001';

WHERE a.rsNum='rs000002';





CREATE TABLE PERSONAL (
  pNum varchar(8) PRIMARY key, --고유번호
  pName varchar2 (100),        -- 성명
  pID varchar2(15),            -- 아이디 
  pPW varchar2(20),            -- 비밀번호
  pMail varchar2(30),          -- 이메일
  pHP varchar2(15),            -- 연락처
  birth date,                  -- 생년월일
  gender number                -- 성별(1:남, 2:여)
);
DROP TABLE personal;
INSERT INTO personal VALUES ('pm000001', '홍길동', 'qwerty', 'tiger', 'qwerty@gmail.com', '01011112222', '1990-01-01', 2);
SELECT * FROM PERSONAL ;





CREATE TABLE RECRUIT (
  rcNum varchar(8) PRIMARY KEY , -- 채용공고 고유번호 (pk)
  cNum varchar(8)  CONSTRAINT recruit_cNum_nn NOT NULL REFERENCES COMPANYINFO(cnum) , -- 회원 고유번호 ◀ (기업회원DB 조인에 사용)
  rcTitle varchar(300)  CONSTRAINT rcTitle_cNum_nn NOT NULL, -- 채용공고 제목
  deadline DATE  CONSTRAINT recruit_deadline_nn NOT NULL , -- 공고 마감일
  progress NUMBER  CONSTRAINT recruit_progress_nn NOT NULL, -- 상태 (ex. 1: 채용 진행중, 2:공고 마감)
  address1 varchar(300), -- 근무지 주소 (다음 주소 api의 roadAddress를 받아옴)
  address2 varchar(600), -- 근무지 상세주소
  --area varchar(300) -- 근무지역 (검색에서 사용됨. 다음 주소 api의 법정동코드bcode 받아옴.. ex.1111010100:서울특별시 종로구 청운동)
  career NUMBER REFERENCES career(cnum), -- 경력 (ex. 1:'신입', 2:'1~3년' ..)
  education NUMBER REFERENCES education(enum), -- 최종학력 (ex. 1:'초등학교 졸업', 2:'중학교 졸업' ..)
  empType NUMBER REFERENCES empType(etNum), -- 고용형태 (ex. 1: 정규직, 2: 계약직 ...) 
  occupation NUMBER REFERENCES occupation(onum), -- 산업 (ex. 100:'서비스업', 200:'금융,은행업'..)
  title NUMBER REFERENCES jobtitle(jtnum), --직급 (ex. 1:사원급, 2: 주임~대리급)
  position NUMBER REFERENCES jobposition(jpNum), --직책 (ex. 1:팀장/매니저/실장, 2:파트장/그룹장..)
  salary NUMBER REFERENCES salary(snum), -- 연봉 (ex. 1:'회사 내규에 따름', 2:'~2000만원'..)
  dept varchar2(100), --직무
  prefer varchar2(300) -- 우대조건
);

DROP TABLE RECRUIT;


SELECT RCNUM "공고번호", a.CNUM "기업회원고유번호", 
RCTITLE "공고명", to_char(DEADLINE,'YYYY-MM-DD') "마감일", 
decode(progress, 1, '채용 진행중', 2, '공고 마감') "상태", 
ADDRESS1 "근무",ADDRESS2 "상세주소", c.CSTR "경력", 
e.ESTR "최종학력", p.ETSTR "고용형태", o.OSTR "산업", j.JTSTR "직급", 
jp.JPSTR "직책", s.SSTR "연봉", DEPT "직무", PREFER "우대조건"
FROM RECRUIT a, CAREER c, education e, 
EMPTYPE p, OCCUPATION o,
JOBTITLE j, JOBPOSITION jp, SALARY s
WHERE a.EDUCATION = e.ENUM 
AND a.CAREER = c.CNUM 
AND a.EMPTYPE = p.ETNUM 
AND a.OCCUPATION = o.ONUM
AND a.TITLE = j.JTNUM
AND a.POSITION = jp.JPNUM 
AND a.SALARY = s.SNUM;








-- 채용공고/기업정보 기본!!!!!!!!!!!!!!!!
SELECT RCTITLE 공고명, to_char(DEADLINE,'YYYY-MM-DD') 마감일, 
decode(progress, 1, '채용 진행중', 2, '공고 마감') "상태", 
ADDRESS1 근무지,ADDRESS2 상세주소, c.CSTR 경력, e.ESTR 최종합력, 
p.ETSTR 고용형태, o.OSTR 산업, j.JTSTR 직급, 
jp.JPSTR 직책, s.SSTR 연봉, DEPT 직무, PREFER 우대조건
FROM RECRUIT a, CAREER c, education e, 
EMPTYPE p, OCCUPATION o,
JOBTITLE j, JOBPOSITION jp, SALARY s
WHERE a.EDUCATION = e.ENUM 
AND a.CAREER = c.CNUM 
AND a.EMPTYPE = p.ETNUM 
AND a.OCCUPATION = o.ONUM
AND a.TITLE = j.JTNUM
AND a.POSITION = jp.JPNUM 
AND a.SALARY = s.SNUM
AND RCTITLE Like '%기숙사%' AND ADDRESS1 Like '%경기%';


INSERT INTO recruit VALUES ('RC001-SK', 'cm000001', '이천SK하이닉스/연봉3천/8H근무/기숙사','2021-08-09', 1, '경기도 이천시', '하이닉스본사',
							2, 3, 2, 500, 2, 0, 4, '보안 및 시설관리', '장기근속가능자 우대');
INSERT INTO recruit VALUES ('RC001-ST', 'cm000002', '셀트리온 신입/경력 2차 수시채용','2021-07-21', 1, '인천시 연수구', '아카데미로 23 (송도동, (주)셀트리온)',
							2, 4, 1, 800, 2, 0, 1, '생명공학연구원', '영어 능통자 우대');
INSERT INTO recruit VALUES ('RC001-SS', 'cm000003', '삼성전자] 에어컨 설치기사 정직원구합니다.','2021-08-15', 1, '서울시 종로구', '전역',
							2, 3, 2, 300, 2, 0, 4, '에어컨설치', '출장가능자 우대');
INSERT INTO recruit VALUES ('RC001-KT', 'cm000004', 'kt m&s 영업전문가 모집','2021-09-20', 1, '전남 순천시', '신대지구',
							1, 3, 1, 300, 1, 0, 4, '영업전문가', null);
INSERT INTO recruit VALUES ('RC001-LG', 'cm000005', '[H&A본부] 2021 미국 테네시생산법인 기능직 인턴','2021-07-05', 1, '미국 테네시', null,
							1, 4, 1, 300, 1, 0, 1, '기계/전기/전자 기능직', '해외근무 가능자');
INSERT INTO recruit VALUES ('RC001-CJ', 'cm000006', 'CJ제일제당 정규직/인턴매니저 채용 공고','2021-07-04', 1, '전국', null,
							1, 3, 1, 400, 1, 1, 1, '홀서비스매니져', '호텔 관련 학과 전공자');
							-- 넷플릭스는 공고 없어서 제외					
INSERT INTO recruit VALUES ('RC001-SL', 'cm000008', '[신라스테이] 서부산호텔 총지배인 채용','2021-07-30', 1, '부산시 강서구', '명지동 신라스테이서부산점',
							6, 3, 1, 100, 1, 4, 1, '총지배인', NULL); 
INSERT INTO recruit VALUES ('RC001-KR','cm000009', '2021년도 국가철도공단 직원 채용공고','2021-07-07', 1, '전국', null,
							1, 4, 1, 700, 1, 0, 1, '전기/토목/통신 기술직', '다문화 가족의 자녀, 장애인');
INSERT INTO recruit VALUES ('RC001-KB','cm000010', '2021 마이데이터 상담직원 공개채용','2021-07-11', 1, ' 서울 영등포구', null,
							1, 4, 1, 200, 1, 0, 1, '상담직원', null);
						
DROP TABLE COMPANYINFO;
						
INSERT INTO COMPANYINFO 						
values(
'SK하이닉스','cm000001',500,1268103725,28941,
'대기업','1949-10-15',36576,305000,'이석희',6,
'반도체,컴퓨터,통신기기 제조,도매','국민연금, 건강보험, 고용보험, 산재보험',
'www.skhynix.com','경기도 이천시','최상위','꾸준한 연구개발 투자를 합니다.'
);
INSERT INTO COMPANYINFO 
values(
'셀트리온','cm000002',800,1338123603,2158,
'대기업','2002-02-26',1349,10849,'기우성',null,
'바이오,의학연구','국민연금, 건강보험, 고용보험, 산재보험',
'www.celltrion.com','인천시 연수구','최상위','대한민국 대표 바이오 기업입니다.'
);

INSERT INTO COMPANYINFO 
values(
'삼성전자','cm000003',300,1248100998,111143,
'대기업','1969-01-13',8975,1663000,'김기남',4,
'휴대폰,컴퓨터','국민연금, 건강보험, 고용보험, 산재보험',
'www.samsung.com','서울시 서초구','최상위','끊임없는 기술개발을 합니다.'
);
INSERT INTO COMPANYINFO 
values(
'KT		','cm000004',300,1028142945,22349,
'대기업','1981-12-10',15644,178000,'구현모',4,
'유무선통신사업,인터넷','국민연금, 건강보험, 고용보험, 산재보험',
'www.kt.com','경기도 성남시','최상위','초고속 인터넷서비스'
);
INSERT INTO COMPANYINFO 
values(
'LG전자	','cm000005',300,1078614075,39611,
'대기업','1958-10-01',9041,569000,'권봉석',5,
'TV, 컴퓨터','국민연금, 건강보험, 고용보험, 산재보험',
'www.lge.co.kr','서울시 영등포구','최상위','전자제품 생산'
);
INSERT INTO COMPANYINFO 
values(
'CJ제일제당','cm000006',400,1048609535,7721,
'대기업','2007-09-04',819,59808,'손경식',4,
'설탕, 소맥분, 조미식품','국민연금, 건강보험, 고용보험, 산재보험',
'www.cj.co.kr','서울시 중구','최상위','대중의 식탁에 건강을'
);

INSERT INTO COMPANYINFO 
values(
'넷플릭스코리아','cm000007',900,1658700119,92,
'중소기업','2015-01-01',7,4154,'톰',null,
'온라인 미디어','국민연금, 건강보험, 고용보험, 산재보험',
'www.netflix.com','서울시 종로구','우수','스트리밍 서비스'
);

INSERT INTO COMPANYINFO 
values(
'신라스테이','cm000008',100,2018640254,461,
'대기업','2014-06-10',20,835,'박상오',null,
'호텔','국민연금, 건강보험, 고용보험, 산재보험',
'www.shillastay.com','서울시 중구','양호','호텔 서비스입니다.'
);
INSERT INTO COMPANYINFO 
values(
'국가철도공단','cm000009',700,3058213158,1365,
'공기업','2004-01-01',null,14853,'김상균',4,
'철도시설','국민연금, 건강보험, 고용보험, 산재보험',
'www.kr.or.kr','대전시 동구','최상위','국가철도건설합니다.'
);
INSERT INTO COMPANYINFO 
values(
'한국투자증권','cm000010',200,1168104504,2809,
'대기업','1974-09-16',1758,152000,'정일문',5,
'증권투자신탁','국민연금, 건강보험, 고용보험, 산재보험',
'www.truefriend.com','서울시 영등포구','최상위','우리나라 최초 투자신탁회사'
);
						

CREATE TABLE COMPANY (
  cNum varchar(8) PRIMARY key,      -- 기업회원 고유번호
  cName varchar2(100) NOT null,        -- 기업명
  cRegNum number(10) UNIQUE NOT NULL , --사업자등록번호
  cID varchar2(50),                          -- 인사담당 ID
  cPW varchar2(50),                          -- 인사담당 PW
  cMail varchar2(100),                        -- 인사담당 이메일
  cHP varchar2(30)                          -- 인사담당 연락처
);	
						
						
						
						
						
						
						
SELECT a.rcTitle 채용공고제목, cm.cname 기업명,
		decode(a.progress, 1, '채용 진행중', 2, '공고 마감') 상태,
		trunc(a.deadline-SYSDATE) 마감일,
		c.cStr 경력, e.ostr 직종, b.estr 학력, 
		et.ETSTR 고용형태, j.JTSTR 직급, j2.JPSTR 직책, d.SSTR 연봉,
		a.dept 직무, a.prefer 우대조건,
		a.address1 주소1, a.address2 주소2,
		cm.cMail 담당자이메일, cm.cHP 담당자휴대전화
FROM recruit a 
	INNER JOIN education b ON a.education=b.enum 
	INNER JOIN CAREER c ON  a.career=c.cnum
	INNER JOIN salary d ON a.salary=d.snum
	INNER JOIN occupation e ON  a.occupation=e.onum
	INNER JOIN EMPTYPE et ON a.EMPTYPE = et.ETNUM
	INNER JOIN JOBTITLE j ON a.TITLE = j.JTNUM 
	INNER JOIN JOBPOSITION j2 ON a."POSITION"= j2.JPNUM
	inner JOIN company cm ON a.cNum=cm.cNum;

SELECT * FROM RECRUIT
WHERE CONTAINS ('영업');
					
						
CREATE TABLE COMPANY (
  cNum varchar(8) PRIMARY key,      -- 기업회원 고유번호
  cName varchar2(100) NOT null,        -- 기업명
  cRegNum number(10) UNIQUE NOT NULL , --사업자등록번호
  cID varchar2(50),                          -- 인사담당 ID
  cPW varchar2(50),                          -- 인사담당 PW
  cMail varchar2(100),                        -- 인사담당 이메일
  cHP varchar2(30)                          -- 인사담당 연락처
);						
DROP TABLE COMPANY ;
INSERT INTO company values('cm000001', '어쩌구 기업', 1234567899, 'soctt', 'tiger', 'djWjrn@gmail.com', '01012341234' )	;					
INSERT INTO company values('cm000002', '좋은나라', 1234567890, 'wetTissue', 'standard', 'good@gmail.com', '01043214321' )	;					








CREATE TABLE career (
  cNum NUMBER CONSTRAINT career_cnum_pk PRIMARY KEY,
  loCar NUMBER NOT NULL,
  hiCar NUMBER NOT NULL,
  cStr varchar2(100) NOT NULL
);
INSERT INTO career VALUES (1, 0, 0, '신입');
INSERT INTO career VALUES (2, 1, 3, '1~3년');
INSERT INTO career VALUES (3, 4, 6, '4~6년');
INSERT INTO career VALUES (4, 7, 9, '7~9년');
INSERT INTO career VALUES (5, 10, 15, '10~15년');
INSERT INTO career VALUES (6, 16, 20, '15~20년');
SELECT * FROM career;

CREATE TABLE education (
  eNum NUMBER CONSTRAINT education_enum_pk PRIMARY KEY,
  eStr varchar2(100) NOT NULL
);
INSERT INTO education VALUES (1, '초등학교 졸업');
INSERT INTO education VALUES (2, '중학교 졸업');
INSERT INTO education VALUES (3, '고등학교 졸업');
INSERT INTO education VALUES (4, '대학교 졸업 이상');
CREATE TABLE occupation (
	oNum NUMBER CONSTRAINT occupation_oNum_pk PRIMARY KEY,
	oStr varchar2(100) NOT null
);
INSERT INTO occupation VALUES (100, '서비스업');
INSERT INTO occupation VALUES (200, '금융업');
INSERT INTO occupation VALUES (300, 'IT/정보통신');
INSERT INTO occupation VALUES (400, '판매유통');
INSERT INTO occupation VALUES (500, '제조생산');
INSERT INTO occupation VALUES (600, '교육');
INSERT INTO occupation VALUES (700, '건설');
INSERT INTO occupation VALUES (800, '의료/제약');
INSERT INTO occupation VALUES (900, '미디어/예술');
CREATE TABLE salary (
	sNum NUMBER CONSTRAINT salary_sNum_pk PRIMARY KEY,
	losal NUMBER,
 	hisal NUMBER,
	sStr varchar2(100) NOT null
);
INSERT INTO salary VALUES (1, null, NULL, '회사 내규에 따름');
INSERT INTO salary VALUES (2, 0, 2000,  '~2천');
INSERT INTO salary VALUES (3, 2001, 3000, '2천~3천');
INSERT INTO salary VALUES (4, 3001, 4000, '3천~4천');
INSERT INTO salary VALUES (5, 4001, 5000, '4천~5천');
INSERT INTO salary VALUES (6, 5001, 6000, '5천~6천');
INSERT INTO salary VALUES (7, 6001, 99999, '6천이상');
INSERT INTO salary VALUES (8, NULL, NULL, '면접 후 결정');
CREATE TABLE empType (
	etNum NUMBER CONSTRAINT empType_etNum_pk PRIMARY KEY,
	etStr varchar2(100) NOT null
);
INSERT INTO empType VALUES (1, '정규직');
INSERT INTO empType VALUES (2, '계약직');
INSERT INTO empType VALUES (3, '인턴');
INSERT INTO empType VALUES (4, '프리랜서');
INSERT INTO empType VALUES (5, '아르바이트');
CREATE TABLE jobTitle (
	jtNum NUMBER CONSTRAINT jobtitle_jtNum_pk PRIMARY KEY,
	jtStr varchar2(100) NOT null
);
INSERT INTO jobtitle VALUES (1, '사원급');
INSERT INTO jobtitle VALUES (2, '대리급');
INSERT INTO jobtitle VALUES (3, '과장급');
INSERT INTO jobtitle VALUES (4, '부장급');
INSERT INTO jobtitle VALUES (5, '임원');
CREATE TABLE jobPosition (
	jpNum NUMBER CONSTRAINT jobPosition_jpNum_pk PRIMARY KEY,
	jpStr varchar2(100) NOT null
);
INSERT INTO jobPosition VALUES (0, '해당없음');
INSERT INTO jobPosition VALUES (1, '팀장');
INSERT INTO jobPosition VALUES (2, '파트장');
INSERT INTO jobPosition VALUES (3, '센터장');
INSERT INTO jobPosition VALUES (4, '지점장');






