package javaexp.z00_TeamProject;

import java.util.Scanner;

public class D03_Recuit_Main_Show {
	Scanner sc = new Scanner(System.in);
	
	
	public static void main(String[] args) {
		B03_RecruitService sv = new B03_RecruitService ();
		A03_RecruitController ct = new A03_RecruitController ();
		sv.getsearchList();
		ct.getsearchList(new RecruitDB(), new Model());

		sv.detailsearchList();
		ct.detailsearchList(new RecruitDB(), new Model());
	}
}
