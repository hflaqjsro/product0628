package javaexp.z00_TeamProject;

import java.util.ArrayList;

import javaexp.z01_vo.Recruit;

public class A03_RecruitController {
	B03_RecruitService sv = new B03_RecruitService ();

	public String getsearchList(RecruitDB db, Model d) {
		System.out.println("# Controller 처리 [검색] #");
		d.addAttraibute("[검색 조건 내용]", "[검색 결과]");
		return "검색결과 리스트 화면";
	}

	public String detailsearchList(RecruitDB db, Model d) {
		System.out.println("# Controller 처리 [상세검색] #");
		d.addAttraibute("[상세검색 조건 내용]", "[상세검색 결과]");
		return "상세검색결과 리스트 화면";
	}




}
