package javaexp.z00_TeamProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import javaexp.z01_vo.Emp;
import javaexp.z01_vo.Recruit;
import javaexp.z99_database.Main;

public class C03_RecruitDao {

	private Connection con;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	Scanner sc = new Scanner(System.in);
	
	public void setCon() throws SQLException {
		try {
			Class.forName ("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String info = "jdbc:oracle:thin:@localhost:1521:xe";
		con = DriverManager.getConnection(info,"scott","tiger");
		System.out.println("-----------------------------DB 검색결과 -----------------------------");
	}
	
		public ArrayList<Recruit> getsearchList(){
			ArrayList <Recruit> searchlist = new ArrayList<Recruit> ();
			System.out.println("검색 키워드를 입력하세요] ");
			String input = sc.nextLine();
			
			try {
				setCon();

				String query = "SELECT ci.cName 기업명, a.RCTITLE 공고명, to_char(DEADLINE,'YYYY-MM-DD') 마감일, \r\n"
						+ "c.CSTR 경력, e.ESTR 최종학력, p.ETSTR 고용형태, s.SSTR 연봉, a.ADDRESS1 근무지\r\n"
						+ "FROM RECRUIT a\r\n"
						+ "	INNER JOIN COMPANYINFO ci ON a.CNUM = ci.CNUM \r\n"
						+ "	INNER JOIN CAREER c ON a.CAREER = c.CNUM \r\n"
						+ "	INNER JOIN EDUCATION e ON a.EDUCATION = e.ENUM  \r\n"
						+ "	INNER JOIN EMPTYPE p ON a.EMPTYPE = p.ETNUM\r\n"
						+ "	INNER JOIN SALARY s ON a.SALARY = s.SNUM\r\n"
						+ "WHERE c.CSTR LIKE '%"+input+"%' or ci.CNAME LIKE '%"+input+"%' or a.RCTITLE LIKE'%"+input+"%'";

				stmt = con.createStatement();
				rs = stmt.executeQuery(query);

				System.out.println("기업명\t\t\t공고명\t\t\t마감일\t\t경력\t최종학력\t\t\t고용형태\t연봉\t근무지");
				while(rs.next()) {
					System.out.print(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getDate(3)+"\t"+rs.getString(4)+"\t"+rs.getString(5)+"\t"
							+rs.getString(6)+"\t"+rs.getString(7)+rs.getString(8)+"\n");
					searchlist.add(new Recruit(rs.getString(1),
							rs.getString(2), rs.getDate(3), rs.getString(4),
							rs.getString(5), rs.getString(6), rs.getString(7)+rs.getString(8)));					
				}
			
		rs.close(); stmt.close(); con.close();
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	return searchlist;
	}
		
		public ArrayList<Recruit> detailsearchList(){
			ArrayList <Recruit> detailsearchList = new ArrayList<Recruit> ();
			try {
				setCon();

				String query = "SELECT RCTITLE 공고명, to_char(DEADLINE,'YYYY-MM-DD') 마감일, \r\n"
						+ "decode(progress, 1, '채용 진행중', 2, '공고 마감') \"상태\", \r\n"
						+ "ADDRESS1 근무지,ADDRESS2 상세주소, c.CSTR 경력, e.ESTR 최종합력, \r\n"
						+ "p.ETSTR 고용형태, o.OSTR 산업, j.JTSTR 직급, \r\n"
						+ "jp.JPSTR 직책, s.SSTR 연봉, DEPT 직무, PREFER 우대조건\r\n"
						+ "FROM RECRUIT a, CAREER c, education e, \r\n"
						+ "EMPTYPE p, OCCUPATION o,\r\n"
						+ "JOBTITLE j, JOBPOSITION jp, SALARY s\r\n"
						+ "WHERE a.EDUCATION = e.ENUM \r\n"
						+ "AND a.CAREER = c.CNUM \r\n"
						+ "AND a.EMPTYPE = p.ETNUM \r\n"
						+ "AND a.OCCUPATION = o.ONUM\r\n"
						+ "AND a.TITLE = j.JTNUM\r\n"
						+ "AND a.POSITION = jp.JPNUM \r\n"
						+ "AND a.SALARY = s.SNUM\r\n"
						+ "AND RCTITLE Like '%기숙사%' AND ADDRESS1 Like '%경기%' AND s.SSTR LIKE '3천~4천'";

				stmt = con.createStatement();
				rs = stmt.executeQuery(query);

				System.out.println("\t공고명\t\t\t마감일\t\t상태\t\t주소\t\t\t경력\t최종학력\t\t고용형태\t산업\t직책\t직급\t연봉\t\t직무\t\t우대조건");
				while(rs.next()) {
					System.out.print(rs.getString(1)+"\t"+rs.getDate(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4)+" "+rs.getString(5)+"\t"
							+rs.getString(6)+"\t"+rs.getString(7)+"\t"+rs.getString(8)+"\t"+rs.getString(9)+"\t"+rs.getString(10)+"\t"+rs.getString(11)+"\t"+rs.getString(12)
							+"\t"+rs.getString(13)+"\t"+rs.getString(14)+"\n");
					detailsearchList.add(new Recruit(rs.getString(1),rs.getDate(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7)
							,rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getString(12),rs.getString(13),rs.getString(14)));	
				}
			
		rs.close(); stmt.close(); con.close();
	
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	return detailsearchList;
	}
		
		
		
		
	
}


