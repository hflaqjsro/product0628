package teamP_06;

public class BBS {
	private String bbsNum;
	private String memNum;
	private String title;
	private String subtitle;
	private String contents;
	private int available;
	private String bbsDate;
	private int hit;
	private String mName;
	
	public BBS() {
		super();
	}
	public BBS(String memNum, String title, String contents) {
		super();
		this.memNum = memNum;
		this.title = title;
		this.contents = contents;
	}
	public BBS(String memNum, String title, String subtitle, String contents) {
		super();
		this.memNum = memNum;
		this.title = title;
		this.subtitle = subtitle;
		this.contents = contents;
	}
	public BBS(String bbsNum, String memNum, String title, String subtitle, String contents, int available,
			String bbsDate, int hit, String mName) {
		super();
		this.bbsNum = bbsNum;
		this.memNum = memNum;
		this.title = title;
		this.subtitle = subtitle;
		this.contents = contents;
		this.available = available;
		this.bbsDate = bbsDate;
		this.hit = hit;
		this.mName = mName;
	}
	public String getBbsNum() {
		return bbsNum;
	}
	public String getMemNum() {
		return memNum;
	}
	public String getTitle() {
		return title;
	}
	public String getSubtitle() {
		return subtitle;
	}
	public String getContents() {
		return contents;
	}
	public int getAvailable() {
		return available;
	}
	public String getBbsDate() {
		return bbsDate;
	}
	public int getHit() {
		return hit;
	}
	
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public void setBbsNum(String bbsNum) {
		this.bbsNum = bbsNum;
	}
	public void setMemNum(String memNum) {
		this.memNum = memNum;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public void setAvailable(int available) {
		this.available = available;
	}
	public void setBbsDate(String bbsDate) {
		this.bbsDate = bbsDate;
	}
	public void setHit(int hit) {
		this.hit = hit;
	}
	public void setBBSEmpty() {
		this.bbsNum = "0";
		this.memNum = "0";
		this.title = "0";
		this.subtitle = "0";
		this.contents = "0";
		this.available = 0;
		this.bbsDate = "0";
		this.hit = 0;
		this.mName = "0";
	}
	
	
	
	
	
}
